/* © 2026 MisaNeco Works・無断転載・再配布禁止 */
/* 建設スタジオ 無料版の見本データ（すべて架空）と、最初の空の状態。
   日付は 2026-10-22（木）を基準に書いてあり、開いた日に合わせて「週単位」でずらす（曜日はそのまま）。 */
(function (root) {
  'use strict';
  var K = root.KL || (typeof require === 'function' ? require('./logic.js') : null);
  var BASE = K.D('2026-10-22');

  function sample(today) {
    var off = Math.floor((today - BASE) / 7) * 7;
    var d = function (s) { return s ? K.iso(K.D(s) + off) : ''; };
    var sites = [
      { id: 's1', name: '青木様邸 外壁塗装', client: '青木 様', status: '施工中', est: 730000, estimate: 'e1' },
      { id: 's2', name: '架空ハイツ 給排水改修', client: '架空不動産（株）', status: '施工中', est: 1200000 },
      { id: 's3', name: '△△町 駐車場土間', client: '架空建設（株）', status: '完了', est: 480000 },
      { id: 's4', name: '森様邸 分電盤交換', client: '森 様', status: '着工前', est: 260000 },
      { id: 's5', name: '中村様邸 屋根塗装', client: '中村 様', status: '見積中', est: 635250, estimate: 'e2' }
    ];
    var L = function (kind, name, qty, unit, price) { return { kind: kind, name: name, qty: qty, unit: unit, price: price, reduced: false }; };
    var estimates = [
      { id: 'e1', no: 'M-2026-0101', date: d('2026-09-28'), days: 30, to: '青木 様', title: '青木様邸 外壁・付帯部 塗装工事', site: 's1',
        rate: 0.05, discount: 7100, round: '切り捨て', lines: [
          L('仮設工事', '足場 架設・解体', 180, 'm2', 850), L('仮設工事', '飛散防止ネット', 180, 'm2', 150),
          L('下地処理', '高圧洗浄', 150, 'm2', 200), L('下地処理', 'クラック補修', 1, '式', 25000),
          L('外壁塗装', '下塗り（シーラー）', 150, 'm2', 700), L('外壁塗装', '中塗り・上塗り（シリコン）', 150, 'm2', 1800),
          L('付帯塗装', '雨樋', 40, 'm', 900), L('付帯塗装', '破風板', 25, 'm', 1200), L('付帯塗装', '軒天', 20, 'm2', 1300)] },
      { id: 'e2', no: 'M-2026-0108', date: d('2026-10-19'), days: 30, to: '中村 様', title: '中村様邸 屋根塗装工事', site: 's5',
        rate: 0.05, discount: 0, round: '切り捨て', lines: [
          L('仮設工事', '足場 架設・解体', 160, 'm2', 850), L('下地処理', '高圧洗浄', 120, 'm2', 200),
          L('屋根塗装', '下塗り', 120, 'm2', 800), L('屋根塗装', '中塗り・上塗り（遮熱）', 120, 'm2', 2400),
          L('付帯塗装', '棟板金', 1, '式', 61000)] }
    ];
    var T = function (id, site, name, who, start, days, state) { return { id: id, site: site, name: name, who: who, start: d(start), days: days, manualEnd: '', state: state }; };
    var tasks = [
      T('t1', 's3', '掘削・型枠', '鈴木', '2026-09-24', 2, '完了'), T('t2', 's3', '土間打設・養生', '鈴木', '2026-09-28', 3, '完了'),
      T('t3', 's1', '足場組立', '架空足場', '2026-10-05', 2, '完了'), T('t4', 's1', '高圧洗浄・養生', '山田', '2026-10-07', 3, '完了'),
      T('t5', 's1', '下塗り・中塗り', '山田', '2026-10-13', 6, '完了'), T('t6', 's1', '上塗り・付帯部', '山田', '2026-10-21', 5, '作業中'),
      T('t7', 's1', '足場解体', '架空足場', '2026-10-28', 1, '未着手'),
      T('t8', 's2', '既設配管撤去', '佐藤', '2026-10-14', 3, '作業中'), T('t9', 's2', '配管・器具取付', '佐藤', '2026-10-19', 8, '作業中'),
      T('t10', 's2', '通水・試験', '佐藤', '2026-10-29', 2, '未着手'),
      T('t11', 's4', '分電盤交換', '高橋', '2026-10-26', 1, '未着手'), T('t12', 's4', '片付け・引渡し', '高橋', '2026-10-27', 1, '未着手')
    ];
    return {
      v: 1,
      sample: true,
      company: { name: 'サンプル塗装店（架空）', address: '〒000-0000 架空県見本市1-2-3', tel: '000-000-0000', regNo: 'T0000000000000', person: '見本 太郎', round: '切り捨て', off: '土日', holidays: true,
        companyHolidays: ['2026-12-29', '2026-12-30', '2026-12-31', '2027-01-02', '2027-01-03'] },
      sites: sites, estimates: estimates, tasks: tasks,
      log: [{ t: K.iso(today), msg: '見本データ（架空）を読み込みました' }],
      seq: 100
    };
  }

  // 最初の空の状態（会社の設定は標準の値、一覧はすべて空）
  function empty(today) {
    return {
      v: 1,
      sample: false,
      company: { name: '', address: '', tel: '', regNo: '', person: '', round: '切り捨て', off: '土日', holidays: true, companyHolidays: [] },
      sites: [], estimates: [], tasks: [],
      log: [{ t: K.iso(today), msg: '建設スタジオ 無料版 v1.0 を使い始めました' }],
      seq: 100
    };
  }

  var api = { sample: sample, empty: empty, BASE: BASE };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.KDATA = api;
})(this);
