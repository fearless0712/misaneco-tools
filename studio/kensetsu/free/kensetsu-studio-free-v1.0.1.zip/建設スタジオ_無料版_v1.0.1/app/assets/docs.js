/* © 2026 MisaNeco Works・無断転載・再配布禁止 */
/* 建設スタジオ 無料版：印刷する見積書の中身を作る。
   金額の計算は logic.js（K.estimate）をそのまま使い、ここでは並べるだけ。
   画面（app.js）とテスト（node）の両方から使う。 */
(function (root) {
  'use strict';
  var K = root.KL || (typeof require === 'function' ? require('./logic.js') : null);
  function esc(s) { return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function jdate(iso) { var n = K.D(iso); if (n === null) return ''; var o = K.ymd(n); return o.y + '年' + o.m + '月' + o.d + '日'; }
  function yenNum(x) { return K.num(x); }

  function fromBlock(c) {
    var h = '<div class="p-from">';
    h += '<b>' + esc(c.name || '（会社名を設定してください）') + '</b>';
    if (c.address) h += '<div>' + esc(c.address) + '</div>';
    if (c.tel) h += '<div>TEL ' + esc(c.tel) + '</div>';
    if (c.person) h += '<div>担当 ' + esc(c.person) + '</div>';
    if (c.regNo) h += '<div>登録番号 ' + esc(c.regNo) + '</div>';
    return h + '</div>';
  }

  // 見積書
  function estimateHtml(e, c) {
    var r = K.estimate(e), lim = K.validUntil(e.date, e.days);
    var h = '<div class="p-doc">';
    h += '<div class="p-head"><h1>御見積書</h1><div class="p-meta"><div>見積番号 ' + esc(e.no) + '</div><div>見積日 ' + jdate(e.date) + '</div>' + (lim === null ? '' : '<div>有効期限 ' + jdate(K.iso(lim)) + '</div>') + '</div></div>';
    h += '<div class="p-row"><div class="p-to"><div class="p-name">' + esc(e.to || '') + '</div><div>件名：' + esc(e.title || '') + '</div><p>下記のとおりお見積りいたします。</p>';
    h += '<div class="p-total"><span>お見積金額（税込）</span><b>¥' + yenNum(r.total) + '</b></div></div>' + fromBlock(c) + '</div>';
    h += '<table class="p-lines"><thead><tr><th>工種</th><th>品名・仕様</th><th class="r">数量</th><th>単位</th><th class="r">単価</th><th class="r">金額</th></tr></thead><tbody>';
    var anyReduced = false;
    e.lines.forEach(function (l, i) {
      var a = r.lines[i].amount; if (a === null && !K.has(l.name) && !K.has(l.kind)) return;
      if (l.reduced) anyReduced = true;
      h += '<tr><td>' + esc(l.kind) + '</td><td>' + esc(l.name) + (l.reduced ? ' ※' : '') + '</td><td class="r">' + esc(l.qty) + '</td><td>' + esc(l.unit) + '</td><td class="r">' + (K.has(l.price) ? yenNum(K.n0(l.price)) : '') + '</td><td class="r">' + (a === null ? '' : yenNum(a)) + '</td></tr>';
    });
    h += '</tbody></table>';
    var rows = [['小計', r.subtotal], ['諸経費（' + K.round(K.n0(e.rate) * 100, 4) + '%）', r.overhead], ['値引き', -r.discount], ['税抜合計', r.excl], ['10%対象（税抜）', r.base10], ['消費税（10%）', r.tax10]];
    if (r.base8) rows.push(['8%対象（税抜）', r.base8], ['消費税（8%）', r.tax8]);
    h += '<table class="p-sum"><tbody>' + rows.map(function (x) { return '<tr><th>' + x[0] + '</th><td class="r">¥' + yenNum(x[1]) + '</td></tr>'; }).join('');
    h += '<tr class="em"><th>合計（税込）</th><td class="r">¥' + yenNum(r.total) + '</td></tr></tbody></table>';
    h += '<p class="p-note">' + (anyReduced ? '※は軽減税率（8%）の対象です。' : '') + '消費税は税率ごとに合計した金額に対して1回だけ端数処理しています（' + esc(e.round || '切り捨て') + '）。</p>';
    return h + '</div>';
  }

  var api = { estimateHtml: estimateHtml, jdate: jdate };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.KDOCS = api;
})(this);
