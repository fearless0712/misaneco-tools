/* © 2026 MisaNeco Works・無断転載・再配布禁止 */
/* 建設スタジオ 無料版の計算部分（ブラウザ・node 共通）。見積と工程表（稼働日）の計算だけ
   Excel版（工事見積書・工程表）と同じ計算ルールで計算する。
   日付は「1970-01-01 を 0 とする通し番号（日）」で扱い、保存は "2026-10-22" の文字列。 */
(function (root) {
  'use strict';

  // ---------- 祝日（内閣府「国民の祝日について」2026年・2027年） ----------
  var HOLIDAYS = [
    ['2026-01-01', '元日'], ['2026-01-12', '成人の日'], ['2026-02-11', '建国記念の日'], ['2026-02-23', '天皇誕生日'],
    ['2026-03-20', '春分の日'], ['2026-04-29', '昭和の日'], ['2026-05-03', '憲法記念日'], ['2026-05-04', 'みどりの日'],
    ['2026-05-05', 'こどもの日'], ['2026-05-06', '振替休日'], ['2026-07-20', '海の日'], ['2026-08-11', '山の日'],
    ['2026-09-21', '敬老の日'], ['2026-09-22', '国民の休日'], ['2026-09-23', '秋分の日'], ['2026-10-12', 'スポーツの日'],
    ['2026-11-03', '文化の日'], ['2026-11-23', '勤労感謝の日'],
    ['2027-01-01', '元日'], ['2027-01-11', '成人の日'], ['2027-02-11', '建国記念の日'], ['2027-02-23', '天皇誕生日'],
    ['2027-03-21', '春分の日'], ['2027-03-22', '振替休日'], ['2027-04-29', '昭和の日'], ['2027-05-03', '憲法記念日'],
    ['2027-05-04', 'みどりの日'], ['2027-05-05', 'こどもの日'], ['2027-07-19', '海の日'], ['2027-08-11', '山の日'],
    ['2027-09-20', '敬老の日'], ['2027-09-23', '秋分の日'], ['2027-10-11', 'スポーツの日'], ['2027-11-03', '文化の日'],
    ['2027-11-23', '勤労感謝の日']
  ];
  var HOL_FROM = 2026, HOL_TO = 2027;
  var WD = ['日', '月', '火', '水', '木', '金', '土'];

  // ---------- 日付 ----------
  function daysIn(y, m) { return new Date(Date.UTC(y, m, 0)).getUTCDate(); }
  function D(s) { // "2026-10-22" → 通し番号。空・不正は null
    if (s === null || s === undefined || s === '') return null;
    if (typeof s === 'number') return s;
    var m = /^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/.exec(String(s).trim());
    if (!m) return null;
    var y = +m[1], mo = +m[2], d = +m[3];
    if (mo < 1 || mo > 12 || d < 1 || d > daysIn(y, mo)) return null;
    return Date.UTC(y, mo - 1, d) / 86400000;
  }
  function ymd(n) { var t = new Date(n * 86400000); return { y: t.getUTCFullYear(), m: t.getUTCMonth() + 1, d: t.getUTCDate() }; }
  function iso(n) { if (n === null || n === undefined) return ''; var o = ymd(n); return o.y + '-' + (o.m < 10 ? '0' : '') + o.m + '-' + (o.d < 10 ? '0' : '') + o.d; }
  function wday(n) { return ((n % 7) + 7 + 4) % 7; } // 0=日
  function md(n) { var o = ymd(n); return o.m + '/' + o.d; }
  function mdw(n) { return md(n) + '(' + WD[wday(n)] + ')'; }
  function todayN(now) { var t = now || new Date(); return Date.UTC(t.getFullYear(), t.getMonth(), t.getDate()) / 86400000; }

  // ---------- 端数（Excel の ROUND／ROUNDDOWN／ROUNDUP と同じ） ----------
  // 浮動小数のずれ（0.1×3 など）を 15 桁で丸めてから処理する
  function clean(x) { return Number(Number(x).toPrecision(15)); }
  function round(x, d) { var k = Math.pow(10, d || 0), a = clean(Math.abs(x) * k); return (x < 0 ? -1 : 1) * Math.round(a) / k || 0; }
  function roundDown(x, d) { var k = Math.pow(10, d || 0), a = clean(Math.abs(x) * k); return (x < 0 ? -1 : 1) * Math.floor(a) / k || 0; }
  function roundUp(x, d) { var k = Math.pow(10, d || 0), a = clean(Math.abs(x) * k); return (x < 0 ? -1 : 1) * Math.ceil(a) / k || 0; }
  function taxRound(x, mode) {
    if (mode === '切り上げ') return roundUp(x, 0);
    if (mode === '四捨五入') return round(x, 0);
    return roundDown(x, 0);
  }
  function n0(v) { var x = typeof v === 'number' ? v : parseFloat(String(v === undefined || v === null ? '' : v).replace(/[,，\s]/g, '')); return isFinite(x) ? x : 0; }
  function has(v) { return v !== null && v !== undefined && String(v).trim() !== ''; }

  // ---------- 見積書 ----------
  // e: { rate（諸経費率 0.05）, discount（値引き）, round（'切り捨て'|'四捨五入'|'切り上げ'）, lines:[{qty, price, reduced}] }
  function estimate(e) {
    var lines = (e.lines || []).map(function (l) {
      var amt = (has(l.qty) && has(l.price)) ? round(n0(l.qty) * n0(l.price), 0) : null;  // 金額＝数量×単価（四捨五入）
      return { amount: amt, reduced: !!l.reduced };
    });
    var subtotal = 0, r8 = 0;
    lines.forEach(function (l) { if (l.amount !== null) { subtotal += l.amount; if (l.reduced) r8 += l.amount; } });
    var overhead = roundDown(subtotal * n0(e.rate), 0);            // 諸経費＝小計×率（切り捨て）
    var excl = subtotal + overhead - n0(e.discount);               // 税抜合計
    var r10 = excl - r8;                                           // 諸経費・値引きは10%の対象
    var tax10 = taxRound(r10 * 10 / 100, e.round);                 // 税率ごとに1回だけ端数処理
    var tax8 = taxRound(r8 * 8 / 100, e.round);
    return { lines: lines, subtotal: subtotal, overhead: overhead, discount: n0(e.discount), excl: excl,
      base10: r10, tax10: tax10, base8: r8, tax8: tax8, tax: tax10 + tax8, total: excl + tax10 + tax8 };
  }
  function validUntil(dateIso, days) { var d = D(dateIso); return (d === null || !has(days)) ? null : d + n0(days); }
  function regNoOk(s) { return !has(s) || (String(s).length === 14 && String(s).charAt(0) === 'T'); }

  // ---------- 工程表（稼働日） ----------
  var HSET = {}; HOLIDAYS.forEach(function (h) { HSET[D(h[0])] = h[1]; });
  // cal: { off: '土日'|'日曜のみ'|'なし', holidays: true/false（国民の祝日を休む）, company: ['2026-12-29', …] }
  function makeCal(o) {
    var c = { off: o.off || '土日', useHol: o.holidays !== false, company: {} };
    (o.company || []).forEach(function (s) { var n = D(s && s.date !== undefined ? s.date : s); if (n !== null) c.company[n] = true; });
    return c;
  }
  function holidayName(n) { return HSET[n] || ''; }
  function isWork(n, cal) {
    if (cal.useHol && HSET[n]) return false;
    if (cal.company[n]) return false;
    var w = wday(n);
    if (cal.off === '土日' && (w === 0 || w === 6)) return false;
    if (cal.off === '日曜のみ' && w === 0) return false;
    return true;
  }
  // 開始日を1日目として、稼働日を n 日数えた日（開始日が休みなら次の稼働日から）。Excel版の「営業日カレンダー」と同じ結果
  function endDate(start, n, cal) {
    var s = D(start); if (s === null || !has(n)) return null;
    n = n0(n); if (n < 1 || n !== Math.floor(n)) return null;
    var d = s, c = 0, guard = 0;
    while (guard++ < 4000) { if (isWork(d, cal)) { c++; if (c === n) return d; } d++; }
    return null; // 範囲外
  }
  function workdaysBetween(a, b, cal) { var c = 0; for (var d = a; d <= b; d++) if (isWork(d, cal)) c++; return c; }
  // task: { start, days, manualEnd, state（'未着手'|'作業中'|'完了'） }
  function taskInfo(t, cal, today) {
    var end = has(t.manualEnd) ? D(t.manualEnd) : endDate(t.start, t.days, cal);
    var s = D(t.start);
    var judge = end === null ? '' : (t.state === '完了' ? '完了' : (end < today ? '遅れ' : ''));
    return { start: s, end: end, judge: judge, workdays: (s !== null && end !== null) ? workdaysBetween(s, end, cal) : 0 };
  }
  // 進み具合：完了の工程は全部、それ以外は「昨日までに過ぎた稼働日」（作業中のみ）を終わった分として数える
  function siteProgress(tasks, cal, today) {
    var all = 0, done = 0, late = 0, first = null, last = null;
    tasks.forEach(function (t) {
      var i = taskInfo(t, cal, today); if (i.end === null) return;
      all += i.workdays;
      if (t.state === '完了') done += i.workdays;
      else if (t.state === '作業中' && i.start < today) done += Math.min(i.workdays, workdaysBetween(i.start, today - 1, cal));
      if (i.judge === '遅れ') late++;
      if (first === null || i.start < first) first = i.start;
      if (last === null || i.end > last) last = i.end;
    });
    return { workdays: all, done: done, ratio: all ? done / all : 0, late: late, first: first, last: last };
  }

  // ---------- 表示 ----------
  function yen(x) { return (x < 0 ? '-' : '') + '¥' + Math.abs(Math.round(x)).toLocaleString('ja-JP'); }
  function num(x, d) { if (x === null || x === undefined || isNaN(x)) return ''; return round(x, d || 0).toLocaleString('ja-JP', { maximumFractionDigits: d || 0 }); }

  var api = {
    HOLIDAYS: HOLIDAYS, HOL_FROM: HOL_FROM, HOL_TO: HOL_TO, WD: WD,
    D: D, iso: iso, ymd: ymd, wday: wday, md: md, mdw: mdw, todayN: todayN,
    round: round, roundDown: roundDown, roundUp: roundUp, taxRound: taxRound, n0: n0, has: has,
    estimate: estimate, validUntil: validUntil, regNoOk: regNoOk,
    makeCal: makeCal, holidayName: holidayName, isWork: isWork, endDate: endDate, workdaysBetween: workdaysBetween, taskInfo: taskInfo, siteProgress: siteProgress,
    yen: yen, num: num
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.KL = api;
})(this);
