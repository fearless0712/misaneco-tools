/* © 2026 MisaNeco Works・無断転載・再配布禁止 */
/* 建設スタジオ 無料版 v1.0（MisaNeco Works）：画面の部分。見積書と工程表だけの版。
   計算は logic.js（Excel版と同じルール）、見本は data.js、バックアップの検証は backup.js。
   データは localStorage だけに保存（外部送信なし）。最初は空。見本データは「設定・バックアップ」から入れる。
   動きは requestAnimationFrame（30コマ/秒まで、見えないときは止める）。
   ?today=2026-10-22 … 「今日」を固定（説明書のスクリーンショット用） */
(function () {
  'use strict';
  var K = window.KL, DATA = window.KDATA, BK = window.KBACKUP;

  // 製品版の案内（リンク先はここ1か所だけ。押したときだけブラウザで開く）
  // 無料版には、これらの機能のコードは入っていない。メニューのボタンと案内の窓だけ。
  var PRO = {
    url: 'https://tools.equaglobal.com/ig/#studio',
    items: [
      { key: 'genka', label: '日報 → 原価・粗利', short: '日報から原価・粗利の計算', desc: '日報に入れた人工が、現場の原価と粗利に自動で入ります。' },
      { key: 'seikyu', label: '請求・入金', short: '請求・入金の管理', desc: '見積から請求予定ができ、請求書の印刷と入金の記録で、未入金と遅れが分かります。' },
      { key: 'gaichu', label: '外注支払', short: '外注支払の管理', desc: '協力会社の締め日・支払日のルールから、支払予定日と未払いを出します。' },
      { key: 'kigen', label: '期限管理', short: '期限（許可・資格・車検など）の管理', desc: '建設業許可・資格・保険・車検などの期限を、残り日数と色で知らせます。' },
      { key: 'tosou', label: '塗装計算', short: '塗料の量と缶数の計算', desc: '外壁・屋根の面積から、工程ごとの塗料の量と缶数を出します。' },
      { key: 'matome', label: '全体のまとめ', short: '全体のまとめ', desc: '今月の売上・粗利・未入金と、現場の進み具合を、ひとつの画面で見られます。' }
    ]
  };

  var Q = new URLSearchParams(location.search);
  var KEY = 'kensetsu-studio-free-v1', KEY_BROKEN = 'kensetsu-studio-free-v1-broken', KEY_BK = 'kensetsu-studio-free-v1-lastbackup';
  var VERSION = '1.0';
  var TODAY = K.D(Q.get('today')) || K.todayN();
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function esc(s) { return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var yen = K.yen, n0 = K.n0;

  // ================= 保存 =================
  var S, storageOk = true;
  var brokenKept = false;
  function load() {
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { storageOk = false; }
    if (raw) {
      var r = BK.parseState(raw);
      if (r.ok) return r.data;
      // 読めないデータは消さずに別の名前で残してから、空で始める
      try { localStorage.setItem(KEY_BROKEN, raw); brokenKept = true; } catch (e) { /* 残せなければ上書きしない */ storageOk = false; }
    }
    return DATA.empty(TODAY);
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(S)); storageOk = true; }
    catch (e) { storageOk = false; }
    showWarn();
  }
  function lastBackup() { try { return localStorage.getItem(KEY_BK) || ''; } catch (e) { return ''; } }
  function isEmpty() { return !S.sites.length && !S.estimates.length && !S.tasks.length; }
  function showWarn() {
    var w = $('#warn'), msg = [];
    if (!storageOk) msg.push('このブラウザでは保存できません（プライベートモード・保存の容量いっぱいなど）。ページを閉じると入力は消えます。すぐに「バックアップを保存」してください。');
    if (brokenKept) msg.push('前回のデータが読めなかったため、空の状態で開きました。前回のデータは消さずに残してあります。バックアップのファイルがあれば「バックアップから戻す」で戻せます。');
    var y = K.ymd(TODAY).y;
    if (y < K.HOL_FROM || y > K.HOL_TO) msg.push('祝日は ' + K.HOL_FROM + '〜' + K.HOL_TO + '年分だけ入っています。それ以外の年は「設定」の会社の休みに足してください。');
    w.hidden = !msg.length; w.textContent = msg.join(' ');
  }
  function uid(p) { S.seq = (S.seq || 100) + 1; return p + S.seq; }
  function log(msg) { S.log.unshift({ t: K.iso(TODAY), msg: msg }); S.log = S.log.slice(0, 30); }

  // ================= 時計・動き =================
  var tweens = [], timers = [], running = false, lastTs = -1;
  function now() { return performance.now(); }
  function ease(p) { return 1 - Math.pow(1 - p, 3); }
  function tween(dur, fn, done, ez) { var t = { t0: now(), dur: dur, fn: fn, done: done, ez: ez || ease }; tweens.push(t); fn(0); kick(); return t; }
  function wait(ms) { return new Promise(function (res) { timers.push({ at: now() + ms, res: res }); kick(); }); }
  function frame() {
    var t = now();
    var ts = tweens.slice(); tweens = [];
    ts.forEach(function (x) { var p = Math.min(1, (t - x.t0) / x.dur); x.fn(x.ez(p)); if (p < 1) tweens.push(x); else if (x.done) x.done(); });
    var due = timers.filter(function (x) { return x.at <= t; }); timers = timers.filter(function (x) { return x.at > t; });
    due.forEach(function (x) { x.res(); });
  }
  function loop(ts) {
    if (!running) return;
    if (document.hidden) { running = false; return; }
    if (lastTs < 0 || ts - lastTs >= 33) { lastTs = ts; frame(); }   // 30コマ/秒まで
    if (tweens.length || timers.length) requestAnimationFrame(loop); else running = false;
  }
  function kick() { if (running || document.hidden) return; running = true; lastTs = -1; requestAnimationFrame(loop); }
  document.addEventListener('visibilitychange', function () { if (!document.hidden) kick(); });
  window.__studio = { ready: null, state: function () { return JSON.parse(JSON.stringify(S)); }, view: function () { return view; } };

  // 数字のカウントアップ（前の値から新しい値へ）
  var shown = {};
  function animate(root) {
    $$('[data-k]', root).forEach(function (el) {
      var k = el.getAttribute('data-k'), v = parseFloat(el.getAttribute('data-v'));
      if (isNaN(v)) { el.textContent = '—'; return; }
      var from = shown.hasOwnProperty(k) ? shown[k] : 0; shown[k] = v;
      if (from === v) { el.textContent = yen(v); return; }
      tween(1100, function (p) { el.textContent = yen(from + (v - from) * p); });
    });
  }
  function cnt(k, v) { return '<span data-k="' + esc(k) + '" data-v="' + (v === null || v === undefined ? 'x' : v) + '"></span>'; }
  function toast(msg) {
    var el = $('#toast'); el.textContent = msg;
    tween(2600, function (p) { el.style.opacity = p < .1 ? p * 10 : (p > .85 ? (1 - p) / .15 : 1); }, null, function (p) { return p; });
  }

  // ================= 共通 =================
  function cal() { return K.makeCal({ off: S.company.off, holidays: S.company.holidays, company: S.company.companyHolidays }); }
  function site(id) { return S.sites.filter(function (s) { return s.id === id; })[0]; }
  function siteName(id) { var s = site(id); return s ? s.name : ''; }
  var COLORS = ['#ff9142', '#4cc9f0', '#3ddc97', '#b18cff', '#f2c65a', '#ff7ab6', '#7ae0ff'];
  function siteColor(id) { var i = S.sites.map(function (s) { return s.id; }).indexOf(id); return COLORS[(i < 0 ? 0 : i) % COLORS.length]; }
  function shortSite(id) { var n = siteName(id); return n.split(/[ 　]/)[0]; }
  function pill(st) {
    var m = { '遅れ': 'bad', '完了': 'ok', '作業中': 'info', '未着手': 'mut' };
    return st ? '<span class="pill ' + (m[st] || 'mut') + '">' + esc(st) + '</span>' : '';
  }
  function fld(lab, input, cls) { return '<label class="f' + (cls ? ' ' + cls : '') + '">' + lab + input + '</label>'; }
  function trim(s, n) { s = String(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; }
  function proHtml() {
    return '<p class="pro-h">製品版でできること</p><ul>' + PRO.items.map(function (x) { return '<li>' + esc(x.label) + '</li>'; }).join('') + '</ul>' +
      '<a class="pro-link" href="' + esc(PRO.url) + '" target="_blank" rel="noopener noreferrer">製品版を見る</a>';
  }
  // メニューの「製品版の機能」ボタン（押すと案内の窓）
  var LOCK = '<svg class="lock-i" viewBox="0 0 12 14" width="10" height="12" aria-hidden="true"><rect x="1" y="6" width="10" height="7.5" rx="1.5" fill="currentColor"/><path d="M3.2 6V4.3a2.8 2.8 0 0 1 5.6 0V6" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>';
  function proNavHtml() {
    return '<p class="nav-pro-h">製品版の機能</p>' + PRO.items.map(function (x) {
      return '<button type="button" class="pro-btn" data-act="pro-info" data-k="' + x.key + '" aria-haspopup="dialog">' + LOCK + '<span>' + esc(x.label) + '</span><em class="pro-tag">製品版</em></button>';
    }).join('');
  }
  // 押した機能以外から3つ（並び順で次の3つ）
  function proOthers(k) {
    var i = PRO.items.map(function (x) { return x.key; }).indexOf(k), out = [];
    for (var j = 1; j <= 3; j++) out.push(PRO.items[(i + j) % PRO.items.length]);
    return out;
  }
  var proLast = null;
  function openPro(k, from) {
    var it = PRO.items.filter(function (x) { return x.key === k; })[0]; if (!it) return;
    var box = $('#proModal');
    box.innerHTML = '<div class="pm-card" role="dialog" aria-modal="true" aria-labelledby="pmTitle"><p class="pm-tag">' + LOCK + ' 製品版の機能</p><h2 id="pmTitle">' + esc(it.label) + '</h2>' +
      '<p class="pm-desc">' + esc(it.desc) + '</p>' +
      '<p>この機能は製品版でお使いいただけます。製品版では、ほかにも' + proOthers(k).map(function (x) { return '<b>' + esc(x.short) + '</b>'; }).join('、') + 'ができます。</p>' +
      '<p class="note">無料版で入れた見積・現場・工程表は、バックアップのファイルで製品版にそのまま移せます。</p>' +
      '<div class="btns pm-btns"><a class="btn" id="pmGo" href="' + esc(PRO.url) + '" target="_blank" rel="noopener noreferrer">製品版を見る</a><button type="button" class="ghost" data-act="pro-close" id="pmClose">閉じる</button></div></div>';
    box.hidden = false; proLast = from || null;
    var c = $('#pmClose'); if (c) c.focus();
  }
  function closePro() {
    var box = $('#proModal'); if (box.hidden) return;
    box.hidden = true; box.innerHTML = '';
    if (proLast && proLast.focus) proLast.focus(); proLast = null;
  }

  // ================= 画面の切りかえ =================
  var view = 'est';
  var TITLES = { est: '見積', sched: '現場と工程表', set: '設定・バックアップ' };
  var RENDER = {};
  function go(v) {
    view = v;
    $$('#nav button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-view') === v); });
    $$('.view').forEach(function (s) { s.classList.toggle('on', s.id === 'v-' + v); });
    $('#viewTitle').textContent = TITLES[v];
    $('#main').scrollTop = 0;
    render();
  }
  function render() { RENDER[view](); kick(); }
  function commit() { save(); render(); }

  // ================= 1) 見積 =================
  var curEst = null;
  function est() { var e = S.estimates.filter(function (x) { return x.id === curEst; })[0]; if (!e) { e = S.estimates[0]; curEst = e ? e.id : null; } return e; }
  function newEst() {
    var no = 'M-' + K.ymd(TODAY).y + '-' + String(S.estimates.length + 101).padStart(4, '0');
    var e = { id: uid('e'), no: no, date: K.iso(TODAY), days: 30, to: '', title: '', site: '', rate: 0.05, discount: 0, round: S.company.round, lines: [{ kind: '', name: '', qty: '', unit: '', price: '', reduced: false }] };
    S.estimates.unshift(e); curEst = e.id; return e;
  }
  RENDER.est = function () {
    var e = est(), h = welcomeHtml();
    if (!e) {
      h += '<div class="panel empty-panel"><div class="ph"><h2><b>EST</b>見積</h2></div><p>まだ見積がありません。下のボタンで1件目を作ります。</p><button class="btn big" data-act="new-est" id="newEstFirst">＋ 新しい見積を作る</button><p class="note">見積を作って「この見積で現場を作る」を押すと、現場と工程表が自動でできます。</p></div>';
      $('#v-est').innerHTML = h; return;
    }
    var r = K.estimate(e), lim = K.validUntil(e.date, e.days);
    h += '<div class="btns" style="margin-bottom:12px"><label class="f" style="flex:1;min-width:200px">見積を選ぶ<select data-act="pick-est">';
    S.estimates.forEach(function (x) { h += '<option value="' + x.id + '"' + (x.id === e.id ? ' selected' : '') + '>' + esc(x.no + '　' + (x.title || '（件名なし）')) + '</option>'; });
    h += '</select></label><button class="ghost" data-act="new-est">＋ 新しい見積</button><button class="ghost" data-act="del-est">この見積を消す</button></div>';
    h += '<div class="est-mini" id="estMini"></div>';
    h += '<div class="grid g32"><div class="panel"><div class="ph"><h2><b>EST</b>見積の内容</h2><span class="tag mono">' + esc(e.no) + '</span></div>';
    h += '<div class="form">';
    h += fld('宛先', '<input id="f-est-to" data-bind="est:to" value="' + esc(e.to) + '" placeholder="例：山田 太郎 様">');
    h += fld('件名（工事名）', '<input id="f-est-title" data-bind="est:title" value="' + esc(e.title) + '" placeholder="例：○○様邸 外壁塗装工事">', 'wide');
    h += fld('見積日', '<input type="date" data-bind="est:date" value="' + esc(e.date) + '">');
    h += fld('有効日数', '<input class="num" inputmode="numeric" data-bind="est:days" value="' + esc(e.days) + '">');
    h += fld('有効期限', '<input disabled id="f-est-lim" value="' + (lim === null ? '' : K.iso(lim)) + '">');
    h += fld('諸経費率（%）', '<input class="num" inputmode="decimal" data-bind="est:ratePct" value="' + esc(K.round(n0(e.rate) * 100, 4)) + '">');
    h += fld('値引き（円）', '<input class="num" inputmode="numeric" data-bind="est:discount" value="' + esc(e.discount) + '">');
    h += fld('消費税の端数', '<select data-bind="est:round">' + ['切り捨て', '四捨五入', '切り上げ'].map(function (x) { return '<option' + (x === e.round ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select>');
    h += '</div>';
    h += '<div class="tw mt"><table class="lines" id="estLines"><colgroup><col style="width:14%"><col style="width:25%"><col style="width:10%"><col style="width:9%"><col style="width:13%"><col style="width:6%"><col style="width:16%"><col style="width:7%"></colgroup><thead><tr><th>工種</th><th>品名・仕様</th><th class="r">数量</th><th>単位</th><th class="r">単価</th><th title="軽減税率8%">軽減</th><th class="r">金額</th><th></th></tr></thead><tbody>';
    e.lines.forEach(function (l, i) {
      h += '<tr data-row="' + i + '"><td><input data-bind="line:' + i + ':kind" value="' + esc(l.kind) + '" placeholder="工種"></td><td><input data-bind="line:' + i + ':name" value="' + esc(l.name) + '" placeholder="品名"></td>';
      h += '<td><input class="num" inputmode="decimal" data-bind="line:' + i + ':qty" value="' + esc(l.qty) + '"></td><td><input data-bind="line:' + i + ':unit" value="' + esc(l.unit) + '" list="units" ></td>';
      h += '<td><input class="num" inputmode="numeric" data-bind="line:' + i + ':price" value="' + esc(l.price) + '"></td><td style="text-align:center"><input type="checkbox" data-bind="line:' + i + ':reduced"' + (l.reduced ? ' checked' : '') + '></td>';
      h += '<td class="amt" id="amt-' + i + '">' + (r.lines[i].amount === null ? '' : K.num(r.lines[i].amount)) + '</td><td><button class="ghost sm" data-act="del-line" data-i="' + i + '" aria-label="行を消す">×</button></td></tr>';
    });
    h += '</tbody></table><datalist id="units">' + '式,m,m2,m3,本,個,台,箇所,枚,缶,kg,日,セット'.split(',').map(function (u) { return '<option value="' + u + '">'; }).join('') + '</datalist></div>';
    h += '<div class="btns mt"><button class="ghost" data-act="add-line" id="addLine">＋ 行を足す</button><span class="note">金額＝数量×単価（1円未満は四捨五入）。軽減にチェックした行は8%。</span></div></div>';
    // 合計
    h += '<div class="panel cy"><div class="ph"><h2><b>SUM</b>合計（その場で計算）</h2></div><div class="tot" id="estTot"></div>';
    h += '<div class="mt">';
    if (e.site && site(e.site)) h += '<p class="linked">● この見積から現場「' + esc(siteName(e.site)) + '」を作成済み（「現場と工程表」で見られます）</p>';
    else h += '<button class="btn big" style="width:100%" data-act="make-site" id="makeSite">この見積で現場を作る →</button><p class="note">押すと、現場と、工種ごとの工程（工程表）が自動でできます。</p>';
    h += '<button class="ghost mt" style="width:100%" data-act="print-est" id="printEst">見積書を印刷（PDFにも保存できます）</button>';
    h += '</div><p class="note mt">消費税は、税率ごとに合計した金額に税率をかけて、1回だけ端数処理します（国税庁 インボイスQ&A 問57）。諸経費と値引きは10%の対象として計算します。</p></div></div>';
    $('#v-est').innerHTML = h;
    estTotals(false);
  };
  function estTotals(animateIt) {
    var e = est(); if (!e) return; var r = K.estimate(e), box = $('#estTot'); if (!box) return;
    var rows = [['小計', r.subtotal, 'et-sub'], ['諸経費（' + K.round(n0(e.rate) * 100, 4) + '%・切り捨て）', r.overhead, 'et-ovh'], ['値引き', -r.discount, 'et-dis'], ['税抜合計', r.excl, 'et-excl'],
      ['10%対象（税抜）', r.base10, 'et-b10'], ['消費税（10%）', r.tax10, 'et-t10'], ['8%対象（税抜）', r.base8, 'et-b8'], ['消費税（8%）', r.tax8, 'et-t8']];
    var h = rows.map(function (x) { return '<div class="r"><span>' + x[0] + '</span>' + cnt(x[2], x[1]) + '</div>'; }).join('');
    h += '<div class="r em"><span>合計（税込）</span>' + cnt('et-total', r.total) + '</div>';
    if (!animateIt) rows.concat([[0, r.total, 'et-total']]).forEach(function (x) { shown[x[2]] = x[1]; });
    box.innerHTML = h;
    var mini = $('#estMini'); if (mini) { mini.innerHTML = '<span>税抜 ' + cnt('em-excl', r.excl) + '</span><span>消費税 ' + cnt('em-tax', r.tax) + '</span><span class="em-t">合計 ' + cnt('em-total', r.total) + '</span>'; if (!animateIt) { shown['em-excl'] = r.excl; shown['em-tax'] = r.tax; shown['em-total'] = r.total; } }
    if (animateIt) animate(mini);
    else $$('[data-k]', mini).forEach(function (el) { el.textContent = yen(parseFloat(el.getAttribute('data-v'))); });
    if (animateIt) animate(box); else $$('[data-k]', box).forEach(function (el) { el.textContent = yen(parseFloat(el.getAttribute('data-v'))); });
    r.lines.forEach(function (l, i) { var c = $('#amt-' + i); if (c) c.textContent = l.amount === null ? '' : K.num(l.amount); });
    var lim = K.validUntil(e.date, e.days), li = $('#f-est-lim'); if (li) li.value = lim === null ? '' : K.iso(lim);
    kick();
  }
  // 見積 → 現場・工程
  function makeSite() {
    var e = est(); if (!e) return null;
    var r = K.estimate(e);
    if (r.excl <= 0) { toast('明細を入れてください'); return null; }
    var c = cal(), sid = uid('s');
    var name = (e.title || e.to || '新しい現場').replace(/工事$/, '').replace(/[ 　]+$/, '');
    var s = { id: sid, name: name, client: e.to, status: '着工前', est: r.excl, estimate: e.id };
    S.sites.push(s); e.site = sid;
    // 工種ごとに1工程（日数は金額の目安：10万円ごとに1日、1〜6日）。前の工程の次の稼働日から並べる
    var kinds = [], amt = {};
    e.lines.forEach(function (l, i) { var a = r.lines[i].amount; if (a === null) return; var k = l.kind || l.name || '作業'; if (!(k in amt)) { kinds.push(k); amt[k] = 0; } amt[k] += a; });
    var d = TODAY; while (!K.isWork(d, c)) d++;
    kinds.concat(['片付け・引渡し']).forEach(function (k, i) {
      var days = i < kinds.length ? Math.max(1, Math.min(6, Math.round(amt[k] / 100000))) : 1;
      var t = { id: uid('t'), site: sid, name: k, who: '', start: K.iso(d), days: days, manualEnd: '', state: '未着手' };
      S.tasks.push(t);
      d = K.endDate(t.start, days, c) + 1; while (!K.isWork(d, c)) d++;
    });
    log('見積 ' + e.no + ' から現場「' + name + '」を作成（工程 ' + (kinds.length + 1) + '本）');
    newTasks[sid] = true;
    save();
    toast('現場と工程表を作りました');
    return s;
  }

  // ================= 2) 現場と工程表 =================
  var gStart = null, newTasks = {}, selSite = '';
  RENDER.sched = function () {
    var c = cal();
    if (gStart === null) gStart = TODAY - ((K.wday(TODAY) + 6) % 7) - 7;
    var h = '<div class="panel"><div class="ph"><h2><b>GANTT</b>工程表</h2><div class="btns"><button class="ghost sm" data-act="g-prev">◀ 前の週</button><button class="ghost sm" data-act="g-today">今日</button><button class="ghost sm" data-act="g-next">次の週 ▶</button></div></div>';
    h += '<div class="gantt" id="gantt"></div>';
    h += '<div class="gkey"><span><i style="background:#ff9142"></i>作業中</span><span><i style="background:#4cc9f0"></i>未着手</span><span><i style="background:#3d8f73"></i>完了</span><span><i style="background:#ff5d73"></i>遅れ（終了予定を過ぎて未完了）</span><span><i style="background:#2a3346"></i>期間中の休み</span><span><i style="background:#ff9142;width:2px"></i>今日</span></div></div>';
    // 現場の一覧
    h += '<div class="panel mt"><div class="ph"><h2><b>SITES</b>現場</h2></div><div class="tw"><table><thead><tr><th>現場</th><th class="hide-n">取引先</th><th>状態</th><th class="r">見積（税抜）</th><th class="r hide-n">期間</th><th class="r">進み具合</th><th></th></tr></thead><tbody>';
    S.sites.forEach(function (s) {
      var pr = K.siteProgress(S.tasks.filter(function (t) { return t.site === s.id; }), c, TODAY);
      h += '<tr class="' + (pr.late ? 'late' : '') + '"><td><span style="color:' + siteColor(s.id) + '">●</span> ' + esc(s.name) + '</td><td class="hide-n">' + esc(s.client) + '</td><td><select data-bind="site:' + s.id + ':status">' + ['見積中', '着工前', '施工中', '完了'].map(function (x) { return '<option' + (x === s.status ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select></td>';
      h += '<td class="r mono">' + yen(n0(s.est)) + '</td><td class="r mono hide-n">' + (pr.first !== null ? K.md(pr.first) + '〜' + K.md(pr.last) : '') + '</td><td class="r mono">' + (pr.workdays ? Math.round(pr.ratio * 100) + '%' : '') + (pr.late ? ' ' + pill('遅れ') : '') + '</td><td><button class="ghost sm" data-act="del-site" data-id="' + s.id + '" aria-label="現場を消す">×</button></td></tr>';
    });
    if (!S.sites.length) h += '<tr><td colspan="7" class="note">まだ現場がありません。「見積」で見積を作って「この見積で現場を作る」を押すか、下の「現場を足す」から入れてください。</td></tr>';
    h += '</tbody></table></div>';
    h += '<div class="form mt">' + fld('現場名', '<input id="ns-name" placeholder="例：○○様邸 外壁塗装">', 'wide') + fld('取引先', '<input id="ns-client" placeholder="例：○○ 様">') + fld('状態', '<select id="ns-status"><option>着工前</option><option>施工中</option><option>完了</option><option>見積中</option></select>') + fld('見積（税抜・円）', '<input class="num" id="ns-est">') + '<button class="btn" data-act="add-site" id="addSite">現場を足す</button></div>';
    h += '<p class="note">進み具合は、完了の工程と、作業中の工程の昨日までの稼働日から出しています。</p></div>';
    // 工程の一覧（編集）
    h += '<div class="panel mt"><div class="ph"><h2><b>TASKS</b>工程（開始日と稼働日数 → 終了予定は自動）</h2><label class="f" style="flex-direction:row;align-items:center;gap:6px">現場<select data-act="sel-site"><option value="">すべて</option>' + S.sites.map(function (s) { return '<option value="' + s.id + '"' + (s.id === selSite ? ' selected' : '') + '>' + esc(s.name) + '</option>'; }).join('') + '</select></label></div>';
    h += '<div class="tw"><table><thead><tr><th>現場</th><th>工種・作業</th><th>担当</th><th>開始日</th><th class="r">日数</th><th>終了予定</th><th>状態</th><th></th><th></th></tr></thead><tbody>';
    S.tasks.filter(function (t) { return !selSite || t.site === selSite; }).forEach(function (t) {
      var ti = K.taskInfo(t, c, TODAY);
      h += '<tr class="' + (ti.judge === '遅れ' ? 'late' : '') + '"><td>' + esc(shortSite(t.site)) + '</td><td><input data-bind="task:' + t.id + ':name" value="' + esc(t.name) + '"></td><td><input data-bind="task:' + t.id + ':who" value="' + esc(t.who) + '" style="width:80px"></td>';
      h += '<td><input type="date" data-bind="task:' + t.id + ':start" value="' + esc(t.start) + '"></td><td><input class="num" style="width:54px" data-bind="task:' + t.id + ':days" value="' + esc(t.days) + '"></td>';
      h += '<td class="mono">' + (ti.end === null ? '—' : K.mdw(ti.end)) + '</td><td><select data-bind="task:' + t.id + ':state">' + ['未着手', '作業中', '完了'].map(function (x) { return '<option' + (x === t.state ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select></td><td>' + pill(ti.judge) + '</td><td><button class="ghost sm" data-act="del-task" data-id="' + t.id + '">×</button></td></tr>';
    });
    h += '</tbody></table></div>';
    h += '<div class="form mt">' + fld('現場', '<select id="nt-site">' + S.sites.map(function (s) { return '<option value="' + s.id + '"' + (s.id === selSite ? ' selected' : '') + '>' + esc(s.name) + '</option>'; }).join('') + '</select>') + fld('工種・作業', '<input id="nt-name" placeholder="例：下塗り">') + fld('開始日', '<input type="date" id="nt-start" value="' + K.iso(TODAY) + '">') + fld('稼働日数', '<input class="num" id="nt-days" value="2">') + '<button class="btn" data-act="add-task">工程を足す</button></div>';
    h += '<p class="note mt">開始日を1日目として、休みの曜日（' + esc(S.company.off) + '）・国民の祝日' + (S.company.holidays ? '' : '（休まない設定）') + '・会社の休みを除いて数えます。Excel版の工程表と同じ数え方です。</p></div>';
    $('#v-sched').innerHTML = h;
    drawGantt();
  };
  function drawGantt() {
    var box = $('#gantt'); if (!box) return;
    var c = cal(), W = Math.max(320, box.clientWidth), narrow = W < 600;
    var LW = narrow ? 116 : 210, days = narrow ? 28 : 42, cw = (W - LW) / days, RH = 24, HH = 40;
    var rows = [];
    var sites = S.sites.filter(function (s) { return S.tasks.some(function (t) { return t.site === s.id; }); });
    sites.sort(function (a, b) {
      var fa = K.siteProgress(S.tasks.filter(function (t) { return t.site === a.id; }), c, TODAY).first, fb = K.siteProgress(S.tasks.filter(function (t) { return t.site === b.id; }), c, TODAY).first;
      return (fa || 0) - (fb || 0);
    });
    sites.forEach(function (s) {
      var ts = S.tasks.filter(function (t) { return t.site === s.id; });
      var pr = K.siteProgress(ts, c, TODAY);
      if (pr.last !== null && pr.last < gStart && s.status === '完了') return;
      rows.push({ site: s });
      ts.forEach(function (t) { rows.push({ t: t, i: K.taskInfo(t, c, TODAY) }); });
    });
    var H = HH + rows.length * RH + 6;
    var x = function (n) { return LW + (n - gStart) * cw; };
    var g = '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '">';
    // 休みの列・日付
    for (var k = 0; k < days; k++) {
      var n = gStart + k, o = K.ymd(n), off = !K.isWork(n, c);
      if (off) g += '<rect x="' + x(n).toFixed(1) + '" y="' + 22 + '" width="' + cw.toFixed(1) + '" height="' + (H - 22) + '" fill="#131a28"/>';
      if (o.d === 1 || k === 0) g += '<text class="gm" x="' + (x(n) + 2).toFixed(1) + '" y="12">' + o.m + '月</text>';
      if (cw >= 13 || K.wday(n) === 1) g += '<text class="gd" x="' + (x(n) + cw / 2).toFixed(1) + '" y="34" text-anchor="middle" fill="' + (off ? '#5d6880' : '#8d97ab') + '">' + o.d + '</text>';
      if (K.wday(n) === 1) g += '<line x1="' + x(n).toFixed(1) + '" x2="' + x(n).toFixed(1) + '" y1="22" y2="' + H + '" stroke="#1f2838"/>';
    }
    g += '<line x1="' + LW + '" x2="' + W + '" y1="' + (HH - 2) + '" y2="' + (HH - 2) + '" stroke="#2c3850"/>';
    rows.forEach(function (r, i) {
      var y = HH + i * RH;
      if (r.site) {
        g += '<rect x="0" y="' + y + '" width="' + W + '" height="' + RH + '" fill="rgba(255,255,255,.025)"/>';
        g += '<circle cx="9" cy="' + (y + RH / 2) + '" r="3.5" fill="' + siteColor(r.site.id) + '"/><text class="gs" x="18" y="' + (y + 16) + '">' + esc(trim(r.site.name, narrow ? 9 : 16)) + '</text>';
        return;
      }
      var t = r.t, ti = r.i, late = ti.judge === '遅れ';
      g += '<text class="gl" x="18" y="' + (y + 16) + '" fill="' + (late ? '#ff8b9b' : '#c9d1df') + '">' + esc(trim(t.name, narrow ? 8 : 14)) + '</text>';
      if (ti.start === null || ti.end === null) return;
      var a = Math.max(ti.start, gStart), b = Math.min(ti.end, gStart + days - 1);
      if (b < a) return;
      var col = late ? '#ff5d73' : (t.state === '完了' ? '#3d8f73' : (t.state === '作業中' ? '#ff9142' : '#4cc9f0'));
      var x0 = x(ti.start), grow = newTasks[t.site] ? ' data-grow="' + x0.toFixed(1) + '"' : '';
      g += '<g' + grow + '>';
      g += '<rect x="' + x(a).toFixed(1) + '" y="' + (y + 7) + '" width="' + ((b - a + 1) * cw).toFixed(1) + '" height="' + (RH - 14) + '" rx="3" fill="#2a3346"/>';
      for (var n2 = a; n2 <= b; n2++) if (K.isWork(n2, c)) g += '<rect x="' + (x(n2) + .6).toFixed(1) + '" y="' + (y + 5) + '" width="' + Math.max(1, cw - 1.2).toFixed(1) + '" height="' + (RH - 10) + '" rx="2" fill="' + col + '"/>';
      g += '</g>';
    });
    // 今日の線
    if (TODAY >= gStart && TODAY < gStart + days) {
      var tx = x(TODAY) + cw / 2;
      g += '<line x1="' + tx.toFixed(1) + '" x2="' + tx.toFixed(1) + '" y1="16" y2="' + H + '" stroke="#ff9142" stroke-width="4" opacity=".18"/>';
      g += '<line x1="' + tx.toFixed(1) + '" x2="' + tx.toFixed(1) + '" y1="16" y2="' + H + '" stroke="#ff9142" stroke-width="1.5"/>';
      g += '<rect x="' + (tx - 15).toFixed(1) + '" y="2" width="30" height="14" rx="3" fill="#ff9142"/><text x="' + tx.toFixed(1) + '" y="12.5" text-anchor="middle" font-size="10" font-weight="700" fill="#1a0e04">今日</text>';
    }
    if (!rows.length) g += '<text class="gl" x="18" y="' + (HH + 18) + '">工程はまだありません</text>';
    g += '</svg>';
    box.innerHTML = g;
    // 新しく作った現場の帯は左から伸ばす
    $$('[data-grow]', box).forEach(function (el, i) {
      var x0 = el.getAttribute('data-grow');
      el.setAttribute('transform', 'translate(' + x0 + ',0) scale(0,1) translate(-' + x0 + ',0)');
      wait(i * 140).then(function () {
        tween(700, function (p) { el.setAttribute('transform', 'translate(' + x0 + ',0) scale(' + p.toFixed(3) + ',1) translate(-' + x0 + ',0)'); });
      });
    });
    newTasks = {};
  }

  // ================= 3) 設定 =================
  RENDER.set = function () {
    var c = S.company;
    var h = '<div class="grid g2"><div class="panel"><div class="ph"><h2><b>SET</b>会社と計算の設定</h2></div><div class="form">';
    h += fld('会社名・屋号（見積書に出ます）', '<input id="co-name" data-bind="co:name" value="' + esc(c.name) + '" placeholder="例：○○塗装">', 'wide');
    h += fld('住所', '<input data-bind="co:address" value="' + esc(c.address) + '" placeholder="例：〒000-0000 ○○県○○市…">', 'wide');
    h += fld('電話', '<input data-bind="co:tel" value="' + esc(c.tel) + '" placeholder="例：000-000-0000">');
    h += fld('担当者', '<input data-bind="co:person" value="' + esc(c.person) + '" placeholder="任意">');
    h += fld('登録番号（インボイス・T＋13桁）', '<input id="co-regNo" data-bind="co:regNo" value="' + esc(c.regNo) + '" placeholder="例：T1234567890123"><small id="regNoMsg" class="' + (K.regNoOk(c.regNo) ? 'note' : 'bad') + '">' + (K.regNoOk(c.regNo) ? '登録していない場合は空のままにします' : 'T＋13桁（全部で14文字）で入れてください') + '</small>', 'wide');
    h += fld('消費税の端数（新しい見積）', '<select data-bind="co:round">' + ['切り捨て', '四捨五入', '切り上げ'].map(function (x) { return '<option' + (x === c.round ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select>');
    h += fld('休みの曜日', '<select data-bind="co:off">' + ['土日', '日曜のみ', 'なし'].map(function (x) { return '<option' + (x === c.off ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select>');
    h += fld('国民の祝日', '<select data-bind="co:holidays"><option value="1"' + (c.holidays ? ' selected' : '') + '>休む</option><option value="0"' + (!c.holidays ? ' selected' : '') + '>休まない</option></select>');
    h += fld('会社の休み（1行に1日 2026-12-29）', '<textarea data-bind="co:companyHolidays">' + esc((c.companyHolidays || []).join('\n')) + '</textarea>', 'wide');
    h += '</div><p class="note">休みの曜日・祝日・会社の休みは、工程表の稼働日の数え方に使います。</p></div>';
    h += '<div class="panel cy pro-panel"><div class="ph"><h2><b>PRO</b>製品版について</h2></div>' + proHtml() + '<p class="note">この無料版のバックアップは、製品版の「バックアップから戻す」でそのまま読み込めます（見積・現場・工程表・会社の設定）。</p></div></div>';
    var lb = lastBackup();
    h += '<div class="panel mt" id="dataPanel"><div class="ph"><h2><b>DATA</b>バックアップとデータ</h2><span class="tag">' + (lb ? '前回のバックアップ ' + esc(lb) : 'バックアップはまだありません') + '</span></div>';
    h += '<p class="note">データはこのパソコンのブラウザ（localStorage）にだけ保存しています。インターネットには送信しません。ブラウザの履歴・サイトデータを消すと、入力も消えます。<b>週に1回と、たくさん入力した日の終わり</b>に「バックアップを保存」を押してください。</p>';
    h += '<div class="btns"><button class="btn" data-act="backup" id="btnBackup">バックアップを保存（ファイルをダウンロード）</button><button class="btn cy" data-act="restore" id="btnRestore">バックアップから戻す（ファイルを選ぶ）</button></div>';
    h += '<p class="note">「戻す」を押すと、選んだファイルの中身を確かめてから、今のデータと置きかえます。形が合わないファイルのときは何も変えません。別のパソコンへ移すときも、この2つのボタンを使います。</p>';
    h += '<div class="btns mt"><button class="ghost" data-act="load-sample" id="btnSample">見本データを入れる</button><button class="ghost danger" data-act="clear-all" id="btnClear">すべて消す</button></div>';
    h += '<p class="note">見本データは架空の会社「サンプル塗装店」のデータです。操作を試したあと、「すべて消す」で空に戻してから自分のデータを入れてください。どちらのボタンも、今のデータは消えます（先にバックアップを保存してください）。</p>';
    h += '<p class="note mt">MisaNeco Works ・ 建設スタジオ 無料版 v' + VERSION + '</p></div>';
    h += '<p class="note mt copy">© 2026 MisaNeco Works・無断転載・再配布禁止</p>';
    $('#v-set').innerHTML = h;
  };

  // ================= 入力の受けとり =================
  function onBind(el, final) {
    var b = el.getAttribute('data-bind').split(':'), v = el.type === 'checkbox' ? el.checked : el.value;
    var e, x;
    switch (b[0]) {
      case 'est': e = est();
        if (b[1] === 'ratePct') e.rate = K.has(v) ? n0(v) / 100 : 0; else e[b[1]] = v;
        if (b[1] === 'title' || b[1] === 'to') { var opt = $('[data-act="pick-est"] option[value="' + e.id + '"]'); if (opt) opt.textContent = e.no + '　' + (e.title || '（件名なし）'); }
        save(); estTotals(true); return;
      case 'line': e = est(); e.lines[+b[1]][b[2]] = v; save(); estTotals(true); return;
      case 'site': x = site(b[1]); if (x) { x[b[2]] = v; if (b[2] === 'status') log('現場「' + x.name + '」を ' + v + ' に'); } break;
      case 'task': x = S.tasks.filter(function (t) { return t.id === b[1]; })[0]; if (x) x[b[2]] = v; if (!final && (b[2] === 'name' || b[2] === 'who')) { save(); return; } break;
      case 'co':
        if (b[1] === 'holidays') S.company.holidays = v === '1';
        else if (b[1] === 'companyHolidays') S.company.companyHolidays = String(v).split(/\r?\n/).map(function (s) { return s.trim().split(/\s/)[0]; }).filter(function (s) { return K.D(s) !== null; });
        else S.company[b[1]] = v;
        if (b[1] === 'name') updateHeader();
        if (b[1] === 'regNo') { var rm = $('#regNoMsg'); if (rm) { var okr = K.regNoOk(v); rm.className = okr ? 'note' : 'bad'; rm.textContent = okr ? '登録していない場合は空のままにします' : 'T＋13桁（全部で14文字）で入れてください'; } }
        save(); return;
    }
    commit();
  }
  document.addEventListener('input', function (ev) {
    var el = ev.target; if (!el.getAttribute || !el.hasAttribute('data-bind')) return;
    var k = el.getAttribute('data-bind').split(':')[0];
    if (el.tagName === 'SELECT' || el.type === 'checkbox' || el.type === 'date') return; // change で受ける
    if (k === 'est' || k === 'line' || k === 'co') onBind(el, false);
  });
  document.addEventListener('change', function (ev) {
    var el = ev.target;
    if (el.getAttribute && el.getAttribute('data-act') === 'pick-est') { curEst = el.value; render(); return; }
    if (el.getAttribute && el.getAttribute('data-act') === 'sel-site') { selSite = el.value; render(); return; }
    if (!el.getAttribute || !el.hasAttribute('data-bind')) return;
    onBind(el, true);
  });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') closePro(); });
  document.addEventListener('click', function (ev) {
    if (ev.target && ev.target.id === 'proModal') { closePro(); return; } // 窓の外を押したら閉じる
    var nb = ev.target.closest && ev.target.closest('#nav button'); if (nb) { go(nb.getAttribute('data-view')); return; }
    var b = ev.target.closest && ev.target.closest('[data-act]'); if (!b || b.tagName === 'SELECT') return;
    var a = b.getAttribute('data-act'), id = b.getAttribute('data-id'), e;
    switch (a) {
      case 'goto': go(b.getAttribute('data-v')); return;
      case 'pro-info': openPro(b.getAttribute('data-k'), b); return;
      case 'pro-close': closePro(); return;
      case 'backup': doBackup(); return;
      case 'restore': { var fi = $('#restoreFile'); fi.value = ''; fi.click(); return; }
      case 'load-sample':
        if (!isEmpty() && !window.confirm('今のデータを消して、見本データ（架空の会社）を入れますか？\n消したデータは戻せません。必要なら先に「バックアップを保存」を押してください。')) return;
        replaceState(DATA.sample(TODAY)); toast('見本データ（架空）を入れました'); return;
      case 'clear-all':
        if (!window.confirm('すべてのデータ（会社の設定もふくむ）を消して、空の状態にしますか？\n消したデータは戻せません。必要なら先に「バックアップを保存」を押してください。')) return;
        replaceState(DATA.empty(TODAY)); toast('すべて消しました（空の状態）'); return;
      case 'print-est': { var pe = est(); if (pe) printDoc(window.KDOCS.estimateHtml(pe, S.company)); return; }
      case 'add-site': {
        var ns = { id: uid('s'), name: $('#ns-name').value.trim(), client: $('#ns-client').value.trim(), status: $('#ns-status').value, est: n0($('#ns-est').value) };
        if (!ns.name) { toast('現場名を入れてください'); return; }
        S.sites.push(ns); log('現場を追加：' + ns.name); commit(); toast('現場を足しました'); return;
      }
      case 'del-site': {
        if (!window.confirm('現場「' + siteName(id) + '」と、その工程を消しますか？')) return;
        S.sites = S.sites.filter(function (x) { return x.id !== id; }); S.tasks = S.tasks.filter(function (t) { return t.site !== id; });
        S.estimates.forEach(function (x) { if (x.site === id) x.site = ''; }); commit(); return;
      }
      case 'new-est': newEst(); save(); go('est'); return;
      case 'del-est': e = est(); if (!e || !window.confirm('この見積を消しますか？（作った現場は残ります）')) return; S.estimates = S.estimates.filter(function (x) { return x !== e; }); curEst = null; commit(); return;
      case 'add-line': e = est(); e.lines.push({ kind: '', name: '', qty: '', unit: '', price: '', reduced: false }); save(); render(); return;
      case 'del-line': e = est(); e.lines.splice(+b.getAttribute('data-i'), 1); if (!e.lines.length) e.lines.push({ kind: '', name: '', qty: '', unit: '', price: '', reduced: false }); commit(); return;
      case 'make-site': if (makeSite()) render(); return;
      case 'g-prev': gStart -= 7; render(); return;
      case 'g-next': gStart += 7; render(); return;
      case 'g-today': gStart = null; render(); return;
      case 'add-task': {
        var t = { id: uid('t'), site: $('#nt-site').value, name: $('#nt-name').value || '作業', who: '', start: $('#nt-start').value, days: $('#nt-days').value, manualEnd: '', state: '未着手' };
        if (!t.site || !K.D(t.start) || !(n0(t.days) >= 1)) { toast('現場・開始日・日数を入れてください'); return; }
        S.tasks.push(t); log('工程を追加：' + siteName(t.site) + ' ' + t.name); commit(); return;
      }
      case 'del-task': S.tasks = S.tasks.filter(function (t) { return t.id !== id; }); commit(); return;
    }
  });
  window.addEventListener('resize', function () { if (view === 'sched') drawGantt(); });

  // ================= はじめに・バックアップ・印刷 =================
  function welcomeHtml() {
    if (isEmpty()) {
      var h = '<div class="panel welcome mb"><div class="ph"><h2><b>START</b>はじめに</h2><span class="tag">無料版 v' + VERSION + '</span></div>';
      h += '<ol class="steps"><li><b>設定</b>：会社名・住所・電話・登録番号を入れる（見積書に出ます）</li><li><b>見積</b>：明細を入れると、諸経費・消費税・合計がその場で出る → 見積書を印刷</li><li><b>現場と工程表</b>：「この見積で現場を作る」→ 工種ごとの工程表が自動でできる</li><li><b>バックアップ</b>：「設定・バックアップ」でファイルに保存（製品版にもそのまま移せます）</li></ol>';
      h += '<div class="btns"><button class="btn" data-act="goto" data-v="set" id="wGoSet">① 設定を開く</button><button class="btn cy" data-act="new-est" id="wNewEst">② 見積を作る</button><button class="ghost" data-act="load-sample" id="wSample">先に見本データで試す</button><button class="ghost" data-act="restore">バックアップから戻す</button></div>';
      return h + '<p class="note">データはこのパソコンのブラウザにだけ保存されます。インターネットには送信しません。</p></div>';
    }
    if (S.sample) return '<div class="hintbar mb">いま表示しているのは<b>見本データ（架空の会社）</b>です。自分のデータを入れる前に、<button class="ghost sm" data-act="clear-all">すべて消す</button> で空にしてください。</div>';
    return '';
  }
  function normalize(o) {
    var d = DATA.empty(TODAY);
    Object.keys(d.company).forEach(function (k) { if (!(k in o.company)) o.company[k] = d.company[k]; });
    if (!o.log) o.log = [];
    return o;
  }
  function replaceState(o) {
    S = normalize(o); curEst = null; selSite = ''; shown = {}; gStart = null;
    save(); updateHeader(); go('est');
  }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function stamp() { var t = new Date(); return t.getFullYear() + '-' + pad2(t.getMonth() + 1) + '-' + pad2(t.getDate()) + ' ' + pad2(t.getHours()) + ':' + pad2(t.getMinutes()); }
  function doBackup() {
    var st = stamp(), text = BK.makeBackup(S, st);
    var blob = new Blob([text], { type: 'application/json' }), url = URL.createObjectURL(blob);
    var a = document.createElement('a'); a.href = url; a.download = '建設スタジオ無料版_バックアップ_' + st.replace(/[-: ]/g, '').replace(/^(\d{8})(\d{4})$/, '$1_$2') + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
    try { localStorage.setItem(KEY_BK, st); } catch (e) { /* 記録できなくてもファイルは保存される */ }
    updateHeader(); if (view === 'set') render();
    toast('バックアップを保存しました（ダウンロードのフォルダ）');
  }
  function restoreText(text, fname) {
    var r = BK.parseBackup(text);
    if (!r.ok) { window.alert('このファイルからは戻せませんでした。\n理由：' + r.error + '\n\n今のデータはそのままです（何も変えていません）。'); return false; }
    var d = r.data, msg = 'バックアップ「' + (fname || '') + '」' + (r.savedAt ? '（保存 ' + r.savedAt + '）' : '') + 'の中身：\n会社名 ' + (d.company.name || '（未設定）') + '・見積 ' + d.estimates.length + '件・現場 ' + d.sites.length + '件・工程 ' + d.tasks.length + '本\n\n今のデータを、この中身に置きかえますか？';
    if (!window.confirm(msg)) return false;
    try { localStorage.setItem(KEY + '-before-restore', JSON.stringify(S)); } catch (e) { /* 容量が足りないときは残さない */ }
    replaceState(d); toast('バックアップから戻しました'); return true;
  }
  $('#restoreFile').addEventListener('change', function (ev) {
    var f = ev.target.files && ev.target.files[0]; if (!f) return;
    if (f.size > 20 * 1024 * 1024) { window.alert('ファイルが大きすぎます（20MBまで）。今のデータはそのままです。'); return; }
    var rd = new FileReader();
    rd.onload = function () { restoreText(String(rd.result), f.name); ev.target.value = ''; };
    rd.onerror = function () { window.alert('ファイルを読めませんでした。今のデータはそのままです。'); ev.target.value = ''; };
    rd.readAsText(f, 'utf-8');
  });
  function printDoc(html) {
    var pa = $('#print'); pa.innerHTML = html; document.body.classList.add('printing');
    setTimeout(function () { window.print(); }, 50);
  }
  window.addEventListener('afterprint', function () { document.body.classList.remove('printing'); });
  function daysSince(st) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(st || ''); if (!m) return null; return TODAY - K.D(m[1] + '-' + m[2] + '-' + m[3]); }
  function updateHeader() {
    $('#coName').textContent = S.company.name || '会社名が未設定（「設定・バックアップ」で入れます）';
    $('#chipSample').hidden = !S.sample;
    var lb = lastBackup(), ds = daysSince(lb), el = $('#lastBackup');
    if (!lb) { el.textContent = isEmpty() ? 'バックアップ：まだ保存していません' : 'バックアップ：まだ保存していません。今日のうちに保存しましょう'; el.className = isEmpty() ? 'fict' : 'fict warn'; }
    else { el.textContent = '前回のバックアップ：' + lb + (ds !== null && ds >= 7 ? '（' + ds + '日前）' : ''); el.className = ds !== null && ds >= 7 ? 'fict warn' : 'fict'; }
  }
  window.__studio.restoreText = restoreText; // テスト用（中身の検証は同じ）

  // ================= 起動 =================
  S = normalize(load());
  $('#navPro').innerHTML = proNavHtml();
  updateHeader();
  $('#todayLabel').textContent = '今日 ' + K.iso(TODAY).replace(/-/g, '/') + '（' + K.WD[K.wday(TODAY)] + '）';
  showWarn();
  if (storageOk) save();
  go('est');
  window.__studio.ready = Promise.resolve(true);
})();
