/* © 2026 MisaNeco Works・無断転載・再配布禁止 */
/* 建設スタジオ 無料版：バックアップ（JSONファイル）の作成と検証。
   ・ファイルの形は製品版と同じ（app: 'kensetsu-studio'・format: 1）。製品版の「バックアップから戻す」でそのまま読める。
     製品版だけにある一覧は、空の一覧として書き出す（PRO_LISTS）。無料版のファイルだと分かるように edition: 'free' を付ける。
   ・作る：makeBackup(state, nowIso) → 文字列（ダウンロードする中身）
   ・戻す：parseBackup(text) → { ok:true, data } または { ok:false, error:'理由' }
     形が合わないファイル、無料版にないデータが入ったファイルは ok:false を返すだけで、呼び出し側のデータには触らない。
   画面（app.js）とテスト（node）の両方から使う。外部への送信はしない。 */
(function (root) {
  'use strict';
  var APP = 'kensetsu-studio', FORMAT = 1, EDITION = 'free', MAX_CHARS = 20 * 1024 * 1024;
  var ARRAYS = ['sites', 'estimates', 'tasks'];
  var PRO_LISTS = ['people', 'reports', 'costs', 'bills', 'deadlines', 'partners', 'orders']; // 製品版のファイルの形に合わせるための名前（無料版では使わない）

  function isObj(x) { return x !== null && typeof x === 'object' && !Array.isArray(x); }
  function str(x) { return typeof x === 'string' || typeof x === 'number'; }

  // 状態（S）の形を確かめる（新しいオブジェクトを返す）
  function checkState(o) {
    if (!isObj(o)) return { ok: false, error: '中身がデータの形になっていません' };
    if (o.v !== 1) return { ok: false, error: 'データの版が合いません（v=' + String(o.v) + '）' };
    if (!isObj(o.company)) return { ok: false, error: '会社の設定（company）がありません' };
    var i, j, k;
    for (i = 0; i < ARRAYS.length; i++) {
      k = ARRAYS[i];
      if (!Array.isArray(o[k])) return { ok: false, error: '「' + k + '」の一覧がありません' };
      for (j = 0; j < o[k].length; j++) {
        if (!isObj(o[k][j])) return { ok: false, error: '「' + k + '」の' + (j + 1) + '件目の形が正しくありません' };
        if (!str(o[k][j].id) || String(o[k][j].id) === '') return { ok: false, error: '「' + k + '」の' + (j + 1) + '件目に id がありません' };
      }
    }
    for (i = 0; i < o.estimates.length; i++) if (!Array.isArray(o.estimates[i].lines)) return { ok: false, error: '見積の' + (i + 1) + '件目に明細がありません' };
    if (o.log !== undefined && !Array.isArray(o.log)) return { ok: false, error: '記録（log）の形が正しくありません' };
    var out = { v: 1, sample: !!o.sample, company: JSON.parse(JSON.stringify(o.company)) };
    ARRAYS.forEach(function (a) { out[a] = JSON.parse(JSON.stringify(o[a])); });
    out.log = Array.isArray(o.log) ? JSON.parse(JSON.stringify(o.log)) : [];
    out.seq = (typeof o.seq === 'number' && isFinite(o.seq)) ? o.seq : 100;
    return { ok: true, data: out };
  }

  // 製品版の一覧に1件でもデータがあるか（製品版で入力したデータ）
  function hasProData(o) {
    return PRO_LISTS.some(function (k) { return Array.isArray(o[k]) && o[k].length > 0; });
  }

  function makeBackup(state, nowIso) {
    var data = JSON.parse(JSON.stringify(state));
    PRO_LISTS.forEach(function (k) { data[k] = []; });
    return JSON.stringify({ app: APP, format: FORMAT, edition: EDITION, version: '1.0', savedAt: nowIso || '', data: data }, null, 1);
  }

  function parseJson(text) {
    if (typeof text !== 'string') return { ok: false, error: 'ファイルを読めませんでした' };
    if (text.length > MAX_CHARS) return { ok: false, error: 'ファイルが大きすぎます（20MBまで）' };
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    try { return { ok: true, value: JSON.parse(text) }; }
    catch (e) { return { ok: false, error: 'JSONファイルとして読めません（壊れているか、別のファイルです）' }; }
  }

  // バックアップファイル（app/format 付き）を読む
  function parseBackup(text) {
    var j = parseJson(text); if (!j.ok) return j;
    var o = j.value;
    if (!isObj(o) || o.app !== APP) return { ok: false, error: '建設スタジオのバックアップファイルではありません' };
    if (o.format !== FORMAT) return { ok: false, error: 'バックアップの形式（' + String(o.format) + '）に対応していません' };
    if (isObj(o.data) && hasProData(o.data)) return { ok: false, error: 'このファイルには、無料版にない機能のデータが入っています（製品版のバックアップです）。無料版で開くとそのデータが消えてしまうため、読み込みません。製品版の「バックアップから戻す」で開いてください。' };
    var r = checkState(o.data);
    if (!r.ok) return r;
    return { ok: true, data: r.data, savedAt: typeof o.savedAt === 'string' ? o.savedAt : '' };
  }

  // ブラウザに保存してある状態（localStorage の中身）を読む
  function parseState(text) {
    var j = parseJson(text); if (!j.ok) return j;
    return checkState(j.value);
  }

  var api = { APP: APP, FORMAT: FORMAT, EDITION: EDITION, PRO_LISTS: PRO_LISTS, checkState: checkState, makeBackup: makeBackup, parseBackup: parseBackup, parseState: parseState };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.KBACKUP = api;
})(this);
